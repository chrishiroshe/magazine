﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;
using Wishlist.Domain.Interfaces;
using Wishlist.Domain.Services;

namespace Wishlist.Domain
{
    public class WishlistsServices : IWhishlistServices
    {

        private readonly IWishlistsRepository _whishlistsRepository;

        public WishlistsServices(IWishlistsRepository whishlistsRepository)
        {
            _whishlistsRepository = whishlistsRepository;
        }
        public void CreateWishlist(IList<Wishlists> wishlist)
        {
            try
            { 
                _whishlistsRepository.CreateWishlist(wishlist);
            }
            catch (Exception ex)
            {
                //TODO: IMPLEMENTAR TRATAMENTO DE ERRO
            }
        }

        public IList<Wishlists> GetWishlist(int pageSize, int pageNumber, int userId)
        {
            try
            { 
                return _whishlistsRepository.GetWishlist(pageSize, pageNumber, userId);
            }
            catch (Exception ex)
            {
                return null;
                //TODO: IMPLEMENTAR TRATAMENTO DE ERRO
            }
        }

        public void RemoveWishlist(int userId, int productId)
        {
            try
            { 
                _whishlistsRepository.RemoveWishlist(userId, productId);
            }
            catch (Exception ex)
            {
                //TODO: IMPLEMENTAR TRATAMENTO DE ERRO
            }
        }

    }
}
