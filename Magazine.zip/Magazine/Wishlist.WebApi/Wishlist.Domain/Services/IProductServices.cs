﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;

namespace Wishlist.Domain.Services
{
    public interface IProductServices
    {
        void CreateProduct(Product product);

        IList<Product> GetProducts(int pageSize, int pageNumber);
    }
}
