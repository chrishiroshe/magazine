﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wishlist.Domain.Entities
{
    public class Wishlists
    {
        public int WishlistId { get; set; }

        public int UserId { get; set; }

        public int ProductId { get; set; }
    }
}
