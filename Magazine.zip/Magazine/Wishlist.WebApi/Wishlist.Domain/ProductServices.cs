﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;
using Wishlist.Domain.Interfaces;
using Wishlist.Domain.Services;

namespace Wishlist.Domain
{
    public class ProductServices : IProductServices
    {
        private readonly IProductRepository _productRepository;

        public ProductServices(IProductRepository productRepository)
        {  
            _productRepository = productRepository;
        }
        public void CreateProduct(Product product)
        {
            try
            {
                _productRepository.CreateProduct(product);
            }
            catch (Exception ex)
            {
                //TODO: IMPLEMENTAR TRATAMENTO DE ERRO
            }
        }

        public IList<Product> GetProducts(int pageSize, int pageNumber)
        {
            try
            {
                return _productRepository.GetProducts(pageSize, pageNumber);
            }
            catch (Exception ex)
            {
                return null;
                //TODO: IMPLEMENTAR TRATAMENTO DE ERRO
            }
        }
    }
}
