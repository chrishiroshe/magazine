﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;

namespace Wishlist.Domain.Interfaces
{
    public interface IProductRepository
    {
        void CreateProduct(Product product);
   
        IList<Product> GetProducts(int pageSize, int pageNumber);
    }
}
