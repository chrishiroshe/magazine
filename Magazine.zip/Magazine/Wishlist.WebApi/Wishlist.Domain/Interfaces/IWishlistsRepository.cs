﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;


namespace Wishlist.Domain.Interfaces
{
    public interface IWishlistsRepository
    {

        void CreateWishlist(IList<Wishlists> wishlist);

        void RemoveWishlist(int userId, int productId);

        IList<Wishlists> GetWishlist(int pageSize, int pageNumber, int userId);
    }
}
