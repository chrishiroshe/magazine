﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;

namespace Wishlist.Domain.Interfaces
{
    public interface IUserRepository
    {
        void CreateUser(User user);

        IList<User> GetUsers(int pageSize, int pageNumber);
    }
}
