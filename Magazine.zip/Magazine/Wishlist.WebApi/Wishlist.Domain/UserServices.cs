﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;
using Wishlist.Domain.Interfaces;
using Wishlist.Domain.Services;

namespace Wishlist.Domain
{
    public class UserServices : IUserServices
    {

        private readonly IUserRepository _userRepository;

        public UserServices(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }
        public void CreateUser(User user)
        {
            try
            { 
                _userRepository.CreateUser(user);
            }
            catch (Exception ex)
            {
                //TODO: IMPLEMENTAR TRATAMENTO DE ERRO
            }
        }

        public IList<User> GetUsers(int pageSize, int pageNumber)
        {
            try
            {
                return _userRepository.GetUsers(pageSize, pageNumber);
            }
            catch (Exception ex)
            {
                return null;
                //TODO: IMPLEMENTAR TRATAMENTO DE ERRO
            }
            
}
    }
}
