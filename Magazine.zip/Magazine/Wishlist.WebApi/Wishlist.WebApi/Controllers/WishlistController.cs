﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Wishlist.Domain.Entities;
using Wishlist.Domain.Services;

namespace Wishlist.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WhishlistController : ControllerBase
    {

        private readonly IWhishlistServices _whishlistsService;
        private readonly IUserServices _userService;
        private readonly IProductServices _productService;
        public WhishlistController(IWhishlistServices whishlistsService, IUserServices userService, IProductServices productService)
        {
            _whishlistsService = whishlistsService;
            _userService = userService;
            _productService = productService;
        }
        /// <summary>
        /// Cria Whishlist
        /// </summary>
        /// <param name="wishlist">lista de whilists</param>
        [HttpPost("CreateWishlist/")]
        public JsonResult CreateWishlist([FromBody] IList<Wishlists> wishlist)
        {
            try
            {
                _whishlistsService.CreateWishlist(wishlist);
            }
            catch (Exception e)
            {
                //TODO: IMPLEMENT LOG AND ERRO TREATMENT
                return new JsonResult("erro");
            }
            return new JsonResult(wishlist);
        }
        /// <summary>
        /// Busca  Whishlists por usuario e paginacao
        /// </summary>
        /// <param name="pageSize">tamanhos pagina</param>
        /// <param name="pageNumber">numero da pagina</param>
        ///  <param name="userId">id do usuario</param>
        [HttpGet("GetWishlist/{pageSize}/{pageNumber}/{userId}")]
        public IList<Wishlists> GetWishlist(int pageSize, int pageNumber, int userId)
        {
            IList<Wishlists> lstWhishlists = new List<Wishlists>();
            try
            {
                lstWhishlists = _whishlistsService.GetWishlist( pageSize, pageNumber, userId);
            }
            catch (Exception e)
            {
                //TODO: IMPLEMENT LOG AND ERRO TREATMENT
                return null;
            }
            return lstWhishlists;
        }

        /// <summary>
        /// Exclui Whishlists 
        /// </summary>
        /// <param name="userId"> id usuario</param>
        ///  <param name="productId"> id produto</param>
        [HttpDelete("RemoveWishlist/{userId}/{productId}")]
        public JsonResult RemoveWishlist(int userId, int productId)
        {
            try
            {
                _whishlistsService.RemoveWishlist(userId, productId);
            }
            catch (Exception e)
            {
                //TODO: IMPLEMENT LOG AND ERRO TREATMENT
                return new JsonResult("erro");
            }
            return new JsonResult("ok");
        }

        /// <summary>
        /// Cria Usuario
        /// </summary>
        /// <param name="user">usuario</param>
        [HttpPost("CreateUser/")]
        public JsonResult CreateUser(User user)
        {
            try
            {
                _userService.CreateUser(user);
            }
            catch (Exception e)
            {
                //TODO: IMPLEMENT LOG AND ERRO TREATMENT
                return new JsonResult("erro");
            }
            return new JsonResult(user);
        }
        /// <summary>
        /// Busca  Usuario por paginacao
        /// </summary>
        /// <param name="pageSize">tamanhos pagina</param>
        /// <param name="pageNumber">numero da pagina</param>
        [HttpGet("GetUsers/{pageSize}/{pageNumber}")]
        public IList<User> GetUsers(int pageSize, int pageNumber)
        {
            IList<User> lstUsers = new List<User>();
            try
            {
                lstUsers = _userService.GetUsers(pageSize, pageNumber);
            }
            catch (Exception e)
            {
                //TODO: IMPLEMENT LOG AND ERRO TREATMENT
                return null;
            }
            return lstUsers;
        }

        /// <summary>
        /// Cria Produto
        /// </summary>
        /// <param name="product">produto</param>
        [HttpPost("CreateProduct/")]
        public JsonResult CreateProduct(Product product)
        {
            try
            {
                _productService.CreateProduct(product);
            }
            catch (Exception e)
            {
                //TODO: IMPLEMENT LOG AND ERRO TREATMENT
                return new JsonResult("erro");
            }
            return new JsonResult(product);
        }
        /// <summary>
        /// Busca  Produto por paginacao
        /// </summary>
        /// <param name="pageSize">tamanhos pagina</param>
        /// <param name="pageNumber">numero da pagina</param>
        [HttpGet("GetProducts/{pageSize}/{pageNumber}")]
        public IList<Product> GetProducts(int pageSize, int pageNumber)
        {
            IList<Product> lstProducts = new List<Product>();
            try
            {
                lstProducts = _productService.GetProducts(pageSize, pageNumber);
            }
            catch (Exception e)
            {
                //TODO: IMPLEMENT LOG AND ERRO TREATMENT
                return null;
            }
            return lstProducts;
        }

    }
}
