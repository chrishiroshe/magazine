﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;
using Wishlist.Domain.Interfaces;
using Wishlist.Infra.Data.Context;
using System.Linq;

namespace Wishlist.Infra.Data.Repositories
{
    public class WishlistsRepository : IWishlistsRepository
    {
        #region Variaveis 

        protected new readonly WishlistContext _context;
        #endregion Variaveis

        #region Constructor

        /// <summary>
        /// Constructor Context
        /// </summary>
        /// <param name="context">context</param>
        public WishlistsRepository(WishlistContext context)
        {
            _context = context;
        }
        #endregion Constructor

        public void CreateWishlist(IList<Wishlists> wishlist)
        {
            _context.wishlists.AddRange(wishlist);
            _context.SaveChanges();
        }

        public IList<Wishlists> GetWishlist(int pageSize, int pageNumber, int userId)
        {
            //TEMPORARIAMENTE AQUI POREM EU FARIA EM UMA PROCEDURE
            IList<Wishlists> lstWhishlist =  _context.wishlists.Where(s => s.UserId == userId).OrderBy(s=> s.WishlistId).Skip(pageSize * (pageNumber-1)).Take(pageSize).ToList<Wishlists>();
            return lstWhishlist;
        }

        public void RemoveWishlist(int userId, int productId)
        {
            IList<Wishlists> lstWhishlist = _context.wishlists.Where(s => s.UserId == userId && s.ProductId == productId).ToList<Wishlists>();
            if (lstWhishlist != null && lstWhishlist.Count > 0)
            {
                _context.wishlists.RemoveRange(lstWhishlist);
                _context.SaveChanges();
            }
        }

    }
}
