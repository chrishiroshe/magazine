﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;
using Wishlist.Domain.Interfaces;
using Wishlist.Infra.Data.Context;
using System.Linq;

namespace Wishlist.Infra.Data.Repositories
{
    
    public class ProductRepository : IProductRepository
    {
        #region Variaveis 

        protected new readonly WishlistContext _context;
        #endregion Variaveis

        #region Constructor

        /// <summary>
        /// Constructor Context
        /// </summary>
        /// <param name="context">context</param>
        public ProductRepository(WishlistContext context)
        {
            _context = context;
        }
        #endregion Constructor
        public void CreateProduct(Product product)
        {
            _context.product.Add(product);
            _context.SaveChanges();
        }

        public IList<Product> GetProducts(int pageSize, int pageNumber)
        {
            //TEMPORARIAMENTE AQUI POREM EU FARIA EM UMA PROCEDURE
            IList<Product> lstUser = _context.product.OrderBy(s => s.ProductId).Skip(pageSize * (pageNumber - 1)).Take(pageSize).ToList<Product>();
            return lstUser;
        }
    }
}
