﻿using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;
using Wishlist.Domain.Interfaces;
using Wishlist.Infra.Data.Context;
using System.Linq;

namespace Wishlist.Infra.Data.Repositories
{
    public class UserRepository : IUserRepository
    {
        #region Variaveis 

        protected new readonly WishlistContext _context;
        #endregion Variaveis

        #region Constructor

        /// <summary>
        /// Constructor Context
        /// </summary>
        /// <param name="context">context</param>
        public UserRepository(WishlistContext context)
        {
            _context = context;
        }
        #endregion Constructor
        public void CreateUser(User user)
        {
            _context.user.Add (user);
            _context.SaveChanges();
        }
        public IList<User> GetUsers(int pageSize, int pageNumber)
        {
            //TEMPORARIAMENTE AQUI POREM EU FARIA EM UMA PROCEDURE
            IList<User> lstUser = _context.user.OrderBy(s => s.UserId).Skip(pageSize * (pageNumber - 1)).Take(pageSize).ToList<User>();
            return lstUser;
        }
      
    }
}
