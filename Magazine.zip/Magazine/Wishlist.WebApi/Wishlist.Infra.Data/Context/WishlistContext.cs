﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;
using Wishlist.Infra.Data.EntityConfig;

namespace Wishlist.Infra.Data.Context
{
    public class WishlistContext : DbContext
    {
        public DbSet<User> user { get; set; }
        public DbSet<Product> product { get; set; }

        public DbSet<Wishlists> wishlists { get; set; }

        public WishlistContext(DbContextOptions<WishlistContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasKey(p => p.UserId);
            modelBuilder.Entity<Product>().HasKey(p => p.ProductId);
            modelBuilder.Entity<Wishlists>().HasKey(p => p.WishlistId);

            modelBuilder.ApplyConfiguration(new UserConfig())
                .ApplyConfiguration(new ProductConfig())
                .ApplyConfiguration(new WishlistsConfig());

            base.OnModelCreating(modelBuilder);

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
           => optionsBuilder
               .UseLazyLoadingProxies();

        public override int SaveChanges()
        {
            ChangeTracker.DetectChanges();
            return base.SaveChanges();
        }
    
    }
}
