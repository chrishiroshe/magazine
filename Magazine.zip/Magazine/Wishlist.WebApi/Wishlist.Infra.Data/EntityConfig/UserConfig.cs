﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;

namespace Wishlist.Infra.Data.EntityConfig
{
    public class UserConfig : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.Property(p => p.UserId).HasColumnType("int").IsRequired(true);
            builder.Property(p => p.Name).HasColumnType("varchar(300)").IsRequired(true);
            builder.Property(p => p.Email).HasColumnType("varchar(300)").IsRequired(true);

        }
    }
}
