﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using Wishlist.Domain.Entities;

namespace Wishlist.Infra.Data.EntityConfig
{
    public class ProductConfig : IEntityTypeConfiguration<Product>
    {
        public void Configure(EntityTypeBuilder<Product> builder)
        {
            builder.Property(p => p.ProductId).HasColumnType("int").IsRequired(true);
            builder.Property(p => p.Name).HasColumnType("varchar(300)").IsRequired(true);

        }
    }
}
